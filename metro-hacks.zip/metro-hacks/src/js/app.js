/**
 * TransitPulse — app.js
 * Application entry point: state management, event wiring, render orchestration.
 *
 * Coordinates all modules (data, anomaly, charts, ui, brief) in response to
 * user interactions. Maintains the single source of truth for currentDate,
 * currentOp, ridership, and incidents.
 */

'use strict';

// ── Module imports ───────────────────────────────────────────────────────────
import {
  generateSampleRidership, generateSampleIncidents,
  getDateList, totalRidership, prevDate,
  buildDate, parseRidershipCSV,
} from './data.js';

import { detectExceptions } from './anomaly.js';

import {
  renderTrendChart, renderDonut, renderHBar,
  OP_COLOR,
} from './charts.js';

import {
  renderKPIs, renderExceptionsTable, renderIncidents,
  esc, fmt,
} from './ui.js';

import {
  generateBrief, exportToCSV, downloadFile,
} from './brief.js';

// ── App State ────────────────────────────────────────────────────────────────
let ridership = generateSampleRidership();
let incidents = generateSampleIncidents();
let currentDate, currentOp;
let lastBrief = '';

// ── Clock ─────────────────────────────────────────────────────────────────────
function updateClock() {
  const el = document.getElementById('live-clock');
  if (!el) return;
  const now = new Date();
  el.textContent =
    now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) +
    ' IST · ' +
    now.toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' });
}
setInterval(updateClock, 1000);
updateClock();

// ── Date Selector ─────────────────────────────────────────────────────────────
function setupDateSelect() {
  const sel   = document.getElementById('date-select');
  const dates = getDateList(ridership);
  if (!sel || dates.length === 0) return;

  sel.min = dates[0];
  sel.max = dates[dates.length - 1];

  // Default to latest date if currentDate is out of range
  if (!currentDate || !dates.includes(currentDate)) {
    currentDate = dates[dates.length - 1];
  }
  sel.value = currentDate;
}

document.getElementById('date-select')?.addEventListener('change', function () {
  currentDate = this.value;
  render();
});

document.getElementById('op-filter')?.addEventListener('change', function () {
  currentOp = this.value;
  render();
});

// ── Master Render ─────────────────────────────────────────────────────────────
function render() {
  const dates = getDateList(ridership);

  // ── KPIs ──────────────────────────────────────────────────────────────────
  renderKPIs(ridership, incidents, currentDate, currentOp);

  // ── Trend Chart ───────────────────────────────────────────────────────────
  const trendSvg = document.getElementById('trend-svg');
  const trendLeg = document.getElementById('trend-legend');
  const opList   = currentOp === 'ALL' ? ['METRO', 'BRTS', 'AMTS'] : [currentOp];

  const series = opList.map(op => ({
    op,
    color:  OP_COLOR[op],
    values: dates.map(d => totalRidership(ridership, d, op)),
  }));

  if (trendSvg) renderTrendChart(trendSvg, trendLeg, dates, series, currentDate);

  // ── Donut ─────────────────────────────────────────────────────────────────
  const donutSvg = document.getElementById('donut-svg');
  const donutLeg = document.getElementById('donut-legend');
  const slices   = ['METRO', 'BRTS', 'AMTS'].map(op => ({
    label: op, color: OP_COLOR[op],
    value: totalRidership(ridership, currentDate, op),
  }));
  if (donutSvg) renderDonut(donutSvg, donutLeg, slices);

  // ── Exceptions ────────────────────────────────────────────────────────────
  const excs    = detectExceptions(ridership, currentDate, currentOp);
  const excBody = document.getElementById('exc-body');
  const excWrap = document.getElementById('exc-table-wrap');
  const excEmpty= document.getElementById('exc-empty');
  if (excBody) renderExceptionsTable(excBody, excEmpty, excWrap, excs, incidents);

  const excDateLbl = document.getElementById('exc-date-label');
  if (excDateLbl) excDateLbl.textContent = currentDate;

  // ── Incidents ─────────────────────────────────────────────────────────────
  const dayIncs  = incidents.filter(
    i => i.date === currentDate && (currentOp === 'ALL' || i.operator === currentOp)
  );
  const incList  = document.getElementById('incident-list');
  const incEmpty = document.getElementById('inc-empty');
  if (incList) renderIncidents(incList, incEmpty, dayIncs);

  const incDateLbl = document.getElementById('inc-date-label');
  if (incDateLbl) incDateLbl.textContent = currentDate;

  // ── Bar Charts ────────────────────────────────────────────────────────────
  ['METRO', 'BRTS', 'AMTS'].forEach(op => {
    const elId   = `bars-${op.toLowerCase()}`;
    const el     = document.getElementById(elId);
    const rows   = ridership
      .filter(r => r.date === currentDate && r.operator === op)
      .sort((a, b) => b.ridership - a.ridership);
    if (el) renderHBar(el, rows, OP_COLOR[op], 10);
  });
}

// ── Generate Morning Brief ─────────────────────────────────────────────────────
document.getElementById('btn-brief')?.addEventListener('click', () => {
  const brief = generateBrief(ridership, incidents, currentDate, currentOp);
  lastBrief   = brief;

  const outEl    = document.getElementById('brief-output');
  const phEl     = document.getElementById('brief-placeholder');
  const actEl    = document.getElementById('brief-actions');

  if (outEl) { outEl.textContent = brief; outEl.style.display = 'block'; }
  if (phEl)  phEl.style.display  = 'none';
  if (actEl) actEl.style.display = 'flex';

  outEl?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
});

// ── Download Brief ─────────────────────────────────────────────────────────────
document.getElementById('btn-dl-brief')?.addEventListener('click', () => {
  if (!lastBrief) { alert('Generate the brief first.'); return; }
  downloadFile(lastBrief, `transitpulse-brief-${currentDate}.txt`);
});

// ── Export CSV ─────────────────────────────────────────────────────────────────
document.getElementById('btn-export-csv')?.addEventListener('click', () => {
  const csv = exportToCSV(ridership);
  downloadFile(csv, 'transitpulse-ridership-export.csv', 'text/csv;charset=utf-8');
});

// ── Import CSV ─────────────────────────────────────────────────────────────────
document.getElementById('csv-file-input')?.addEventListener('change', function (e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function (ev) {
    const result = parseRidershipCSV(ev.target.result);

    if (result.imported === 0) {
      alert(
        'CSV import failed — 0 valid rows.\n\n' +
        'Required columns: date (YYYY-MM-DD), operator (METRO/BRTS/AMTS), route_station, ridership\n\n' +
        (result.errors.length ? 'Errors:\n' + result.errors.join('\n') : '')
      );
      return;
    }

    ridership = result.rows;
    setupDateSelect();
    render();

    const statusEl = document.getElementById('import-status');
    if (statusEl) {
      statusEl.textContent = `✓ Imported ${result.imported} rows (${result.skipped} skipped)`;
      statusEl.style.display = 'flex';
      setTimeout(() => { statusEl.style.display = 'none'; }, 5000);
    }

    // Reset brief
    const outEl = document.getElementById('brief-output');
    const phEl  = document.getElementById('brief-placeholder');
    const actEl = document.getElementById('brief-actions');
    if (outEl)  { outEl.style.display = 'none'; outEl.textContent = ''; }
    if (phEl)   phEl.style.display = '';
    if (actEl)  actEl.style.display = 'none';
    lastBrief = '';
  };

  reader.onerror = () => alert('Error reading file.');
  reader.readAsText(file);
  this.value = ''; // allow re-import of same file
});

// ── Reset Sample Data ──────────────────────────────────────────────────────────
document.getElementById('btn-reset')?.addEventListener('click', () => {
  ridership = generateSampleRidership();
  incidents = generateSampleIncidents();
  currentOp = 'ALL';

  const opSel = document.getElementById('op-filter');
  if (opSel) opSel.value = 'ALL';

  setupDateSelect();
  render();

  const outEl = document.getElementById('brief-output');
  const phEl  = document.getElementById('brief-placeholder');
  const actEl = document.getElementById('brief-actions');
  if (outEl)  { outEl.style.display = 'none'; outEl.textContent = ''; }
  if (phEl)   phEl.style.display = '';
  if (actEl)  actEl.style.display = 'none';
  lastBrief = '';
});

// ── Drag-and-Drop import ────────────────────────────────────────────────────────
const dropZone = document.getElementById('drop-zone');
if (dropZone) {
  dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
  dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    const file = e.dataTransfer?.files[0];
    if (!file || !file.name.endsWith('.csv')) { alert('Please drop a .csv file.'); return; }
    const reader = new FileReader();
    reader.onload = ev => {
      const result = parseRidershipCSV(ev.target.result);
      if (result.imported > 0) {
        ridership = result.rows;
        setupDateSelect();
        render();
        alert(`✓ Imported ${result.imported} rows via drag-and-drop.`);
      } else {
        alert('No valid rows found in dropped file.');
      }
    };
    reader.readAsText(file);
  });
}

// ── Bootstrap ─────────────────────────────────────────────────────────────────
(function init() {
  currentOp   = 'ALL';
  const dates = getDateList(ridership);
  currentDate = dates[dates.length - 1]; // default to latest day
  setupDateSelect();
  render();
})();
