/**
 * TransitPulse — charts.js
 * All chart rendering: SVG trend line, donut, horizontal bar charts.
 * Pure functions — take data, write to DOM. No state.
 */

'use strict';

// ── Colour tokens (must stay in sync with CSS custom properties) ───────────
export const OP_COLOR = {
  METRO: '#818cf8',
  BRTS:  '#34d399',
  AMTS:  '#fb923c',
};

const GRID_COLOR  = '#1e2535';
const AXIS_COLOR  = '#2d3448';
const LABEL_COLOR = '#64748b';
const BG_COLOR    = '#0f1117';

// ── Utility ─────────────────────────────────────────────────────────────────

function esc(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function fmtK(n) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
  if (n >= 1_000)     return (n / 1_000).toFixed(1) + 'k';
  return String(n);
}

// ── Trend Line Chart ─────────────────────────────────────────────────────────

/**
 * Render a multi-line SVG trend chart.
 *
 * @param {SVGElement} svgEl     - target <svg> element
 * @param {HTMLElement} legendEl - element to receive HTML legend
 * @param {Array} dates          - array of YYYY-MM-DD strings
 * @param {Array} series         - [{ op: 'METRO', values: [n,...] }, ...]
 * @param {string} selectedDate  - YYYY-MM-DD to highlight with vertical line
 */
export function renderTrendChart(svgEl, legendEl, dates, series, selectedDate) {
  const W = 700, H = 220;
  const PAD = { top: 12, right: 16, bottom: 32, left: 58 };
  const IW = W - PAD.left - PAD.right;
  const IH = H - PAD.top  - PAD.bottom;

  svgEl.setAttribute('viewBox', `0 0 ${W} ${H}`);

  const allVals = series.flatMap(s => s.values);
  if (allVals.length === 0) { svgEl.innerHTML = ''; return; }

  const minV = Math.min(...allVals) * 0.88;
  const maxV = Math.max(...allVals) * 1.06;
  const range = maxV - minV || 1;

  const xPos = i => PAD.left + (i / Math.max(dates.length - 1, 1)) * IW;
  const yPos = v => PAD.top  + IH - ((v - minV) / range) * IH;

  let html = '';

  // Horizontal grid lines (5 levels)
  for (let g = 0; g <= 4; g++) {
    const y   = PAD.top + (g / 4) * IH;
    const val = maxV - (g / 4) * range;
    html += `<line x1="${PAD.left}" y1="${y}" x2="${PAD.left + IW}" y2="${y}"
               stroke="${GRID_COLOR}" stroke-width="1" stroke-dasharray="3,4"/>`;
    html += `<text x="${PAD.left - 5}" y="${y + 3.5}" text-anchor="end"
               font-size="10" fill="${LABEL_COLOR}" font-family="-apple-system,sans-serif">${esc(fmtK(Math.round(val)))}</text>`;
  }

  // X-axis date labels (every other day)
  dates.forEach((d, i) => {
    if (i % 2 !== 0) return;
    const x     = xPos(i);
    const label = d.slice(5); // MM-DD
    html += `<text x="${x}" y="${PAD.top + IH + 18}" text-anchor="middle"
               font-size="10" fill="${LABEL_COLOR}" font-family="-apple-system,sans-serif">${esc(label)}</text>`;
  });

  // Axis lines
  html += `<line x1="${PAD.left}" y1="${PAD.top}" x2="${PAD.left}" y2="${PAD.top + IH}"
             stroke="${AXIS_COLOR}" stroke-width="1"/>`;
  html += `<line x1="${PAD.left}" y1="${PAD.top + IH}" x2="${PAD.left + IW}" y2="${PAD.top + IH}"
             stroke="${AXIS_COLOR}" stroke-width="1"/>`;

  // Selected-date vertical indicator
  const selIdx = dates.indexOf(selectedDate);
  if (selIdx >= 0) {
    const x = xPos(selIdx);
    html += `<line x1="${x}" y1="${PAD.top}" x2="${x}" y2="${PAD.top + IH}"
               stroke="#60a5fa" stroke-width="1.5" stroke-dasharray="4,3" opacity="0.8"/>`;
    html += `<text x="${x}" y="${PAD.top - 3}" text-anchor="middle"
               font-size="10" fill="#60a5fa">▼</text>`;
  }

  // Series lines and dots
  series.forEach(s => {
    const pts = s.values.map((v, i) => `${xPos(i).toFixed(1)},${yPos(v).toFixed(1)}`).join(' ');
    html += `<polyline points="${esc(pts)}" fill="none" stroke="${esc(s.color)}"
               stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>`;
    s.values.forEach((v, i) => {
      const cx = xPos(i).toFixed(1);
      const cy = yPos(v).toFixed(1);
      html += `<circle cx="${cx}" cy="${cy}" r="3.8" fill="${esc(s.color)}"
                 stroke="${BG_COLOR}" stroke-width="1.5"
                 title="${esc(s.op + ': ' + v.toLocaleString('en-IN'))}"/>`;
    });
  });

  svgEl.innerHTML = html;

  // Legend
  if (legendEl) {
    legendEl.innerHTML = series.map(s =>
      `<span class="legend-item">
         <span class="legend-swatch" style="background:${esc(s.color)}"></span>
         ${esc(s.op)}
       </span>`
    ).join('');
  }
}

// ── Donut Chart ──────────────────────────────────────────────────────────────

/**
 * Render a donut chart into an <svg> element.
 *
 * @param {SVGElement}  svgEl    - target <svg>
 * @param {HTMLElement} legendEl - HTML legend container
 * @param {Array}       slices   - [{ label, value, color }, ...]
 */
export function renderDonut(svgEl, legendEl, slices) {
  const CX = 80, CY = 80, OR = 62, IR = 42;
  const total = slices.reduce((s, sl) => s + sl.value, 0);

  if (total === 0) {
    svgEl.innerHTML = `<text x="${CX}" y="${CY + 5}" text-anchor="middle"
      font-size="12" fill="${LABEL_COLOR}">No data</text>`;
    if (legendEl) legendEl.innerHTML = '';
    return;
  }

  let startAngle = -Math.PI / 2;
  let html = '';

  slices.forEach(sl => {
    const fraction  = sl.value / total;
    const angle     = fraction * 2 * Math.PI;
    const endAngle  = startAngle + angle;
    const large     = angle > Math.PI ? 1 : 0;

    const ox1 = CX + OR * Math.cos(startAngle);
    const oy1 = CY + OR * Math.sin(startAngle);
    const ox2 = CX + OR * Math.cos(endAngle);
    const oy2 = CY + OR * Math.sin(endAngle);
    const ix1 = CX + IR * Math.cos(startAngle);
    const iy1 = CY + IR * Math.sin(startAngle);
    const ix2 = CX + IR * Math.cos(endAngle);
    const iy2 = CY + IR * Math.sin(endAngle);

    html += `<path fill="${esc(sl.color)}" opacity="0.92"
               d="M${ox1.toFixed(1)},${oy1.toFixed(1)}
                  A${OR},${OR} 0 ${large},1 ${ox2.toFixed(1)},${oy2.toFixed(1)}
                  L${ix2.toFixed(1)},${iy2.toFixed(1)}
                  A${IR},${IR} 0 ${large},0 ${ix1.toFixed(1)},${iy1.toFixed(1)} Z">
               <title>${esc(sl.label + ': ' + sl.value.toLocaleString('en-IN'))}</title>
             </path>`;
    startAngle = endAngle;
  });

  // Centre text
  html += `<text x="${CX}" y="${CY - 5}" text-anchor="middle"
             font-size="11" fill="${LABEL_COLOR}" font-family="-apple-system,sans-serif">Total</text>`;
  html += `<text x="${CX}" y="${CY + 14}" text-anchor="middle"
             font-size="17" font-weight="800" fill="#f1f5f9"
             font-family="-apple-system,sans-serif">${esc(fmtK(total))}</text>`;

  svgEl.innerHTML = html;

  // Legend
  if (legendEl) {
    legendEl.innerHTML = slices.map(sl => {
      const pct = total > 0 ? ((sl.value / total) * 100).toFixed(1) : '0.0';
      return `<div class="donut-row">
        <span class="donut-swatch" style="background:${esc(sl.color)}"></span>
        <span class="donut-name">${esc(sl.label)}</span>
        <span class="donut-count">${esc(sl.value.toLocaleString('en-IN'))}</span>
        <span class="donut-pct">${esc(pct)}%</span>
      </div>`;
    }).join('');
  }
}

// ── Horizontal Bar Chart ─────────────────────────────────────────────────────

/**
 * Render a horizontal bar chart into a container element.
 *
 * @param {HTMLElement} el       - container div
 * @param {Array}       rows     - [{ route_station, ridership, isAnomaly? }, ...]
 * @param {string}      color    - bar fill colour
 * @param {number}      maxRows  - max bars to display (default 8)
 */
export function renderHBar(el, rows, color, maxRows = 8) {
  if (!el) return;
  if (!rows || rows.length === 0) {
    el.innerHTML = '<div class="empty-state" style="padding:16px">No data for this selection.</div>';
    return;
  }

  const top  = [...rows].sort((a, b) => b.ridership - a.ridership).slice(0, maxRows);
  const maxV = top[0]?.ridership || 1;

  el.innerHTML = top.map(d => {
    const w        = Math.round((d.ridership / maxV) * 100);
    const anomMark = d.isAnomaly ? `<div class="hbar-anomaly-marker" style="left:${esc(d.baselinePct || 50)}%"></div>` : '';
    const deltaHtml = d.delta_pct != null
      ? `<span class="hbar-delta" style="color:${d.delta_pct >= 0 ? '#34d399' : '#f87171'}">${d.delta_pct >= 0 ? '+' : ''}${d.delta_pct.toFixed(0)}%</span>`
      : '';

    return `<div class="hbar-row">
      <div class="hbar-label" title="${esc(d.route_station)}">${esc(d.route_station)}</div>
      <div class="hbar-track">
        <div class="hbar-fill" style="width:${w}%;background:${esc(color)}"></div>
        ${anomMark}
      </div>
      <div class="hbar-val">${esc(fmtK(d.ridership))}</div>
      ${deltaHtml}
    </div>`;
  }).join('');
}
