/**
 * TransitPulse — anomaly.js
 * Anomaly detection engine and evidence-matching layer.
 *
 * Detection method:
 *   1. For each station/route on the selected date, compute a 7-day
 *      rolling average baseline (requires ≥ 3 prior data points).
 *   2. If the current ridership deviates by ≥ ±THRESHOLD_PCT from
 *      baseline → flag as an exception.
 *   3. Severity: |Δ| ≥ SEVERE_PCT → HIGH, else MEDIUM.
 *   4. Evidence matching: compare each exception against incidents
 *      logged on the same date for the same operator + location.
 *      Incidents are presented as possible explanations, never
 *      proven causes.
 */

'use strict';

import { rollingBaseline } from './data.js';

// ── Thresholds ──────────────────────────────────────────────────────────────
export const THRESHOLD_PCT = 20;  // ±20% → flag
export const SEVERE_PCT    = 35;  // ±35% → HIGH severity

/**
 * Detect exceptions for a given date and operator filter.
 *
 * @param {Array}  rows    - full ridership dataset
 * @param {string} date    - YYYY-MM-DD
 * @param {string} op      - 'ALL' | 'METRO' | 'BRTS' | 'AMTS'
 * @returns {Array} sorted array of exception objects (largest |Δ%| first)
 */
export function detectExceptions(rows, date, op = 'ALL') {
  const candidates = rows.filter(
    r => r.date === date && (op === 'ALL' || r.operator === op)
  );

  const exceptions = [];

  for (const r of candidates) {
    const base = rollingBaseline(rows, date, r.operator, r.route_station);
    if (base === null || base === 0) continue;   // guard div-by-zero

    const deltaPct = ((r.ridership - base) / base) * 100;

    if (Math.abs(deltaPct) < THRESHOLD_PCT) continue;

    exceptions.push({
      date,
      operator:     r.operator,
      route_station: r.route_station,
      ridership:    r.ridership,
      baseline:     Math.round(base),
      delta_pct:    deltaPct,
      severity:     Math.abs(deltaPct) >= SEVERE_PCT ? 'HIGH' : 'MEDIUM',
    });
  }

  // Sort by absolute deviation, descending
  exceptions.sort((a, b) => Math.abs(b.delta_pct) - Math.abs(a.delta_pct));
  return exceptions;
}

/**
 * Find incidents that are plausibly related to an exception.
 *
 * Matching criteria:
 *  - Same date
 *  - Same operator
 *  - Location keyword overlap (word length > 3, case-insensitive)
 *
 * @param {Array}  incidents - full incidents dataset
 * @param {object} exc       - exception object from detectExceptions()
 * @returns {Array} matching incident objects
 */
export function findRelatedIncidents(incidents, exc) {
  return incidents.filter(inc => {
    if (inc.date !== exc.date)           return false;
    if (inc.operator !== exc.operator)   return false;

    const sl = exc.route_station.toLowerCase();
    const il = inc.location.toLowerCase();

    // Direct containment
    if (sl.includes(il) || il.includes(sl)) return true;

    // Word-level overlap (words longer than 3 chars to reduce false positives)
    const stationWords = sl.split(/\s+/).filter(w => w.length > 3);
    const locWords     = il.split(/\s+/).filter(w => w.length > 3);
    return stationWords.some(w => locWords.includes(w));
  });
}

/**
 * Build a structured evidence record for one exception.
 *
 * Returns an object with:
 *   facts        — observed data points (always present)
 *   relatedIncs  — matching incidents (may be empty)
 *   hypotheses   — possible explanations (derived from incidents)
 *   actions      — recommended follow-up actions
 *   hasEvidence  — boolean
 */
export function buildEvidence(exc, allIncidents) {
  const related = findRelatedIncidents(allIncidents, exc);
  const sign    = exc.delta_pct >= 0 ? '+' : '';
  const dirWord = exc.delta_pct >= 0 ? 'increase' : 'decrease';

  const facts = [
    `Ridership at ${exc.route_station} (${exc.operator}) on ${exc.date}: ` +
    `${exc.ridership.toLocaleString('en-IN')} passengers.`,
    `7-day rolling average baseline: ${exc.baseline.toLocaleString('en-IN')} passengers.`,
    `Deviation: ${sign}${exc.delta_pct.toFixed(1)}% (${exc.severity} severity).`,
  ];

  const hypotheses = [];
  const actions    = [];

  if (related.length > 0) {
    related.forEach(inc => {
      hypotheses.push(
        `Possible explanation: "${inc.title}" recorded on ${inc.date} at ${inc.location}. ` +
        `${inc.description} [Incident logged — correlation only, causation unconfirmed.]`
      );
    });
    actions.push(`Verify whether the ${related[0].title} fully accounts for the ${dirWord}.`);
    actions.push('Confirm incident resolution status with field supervisor.');
    if (exc.severity === 'HIGH') {
      actions.push('Escalate to duty manager for same-day review.');
    }
  } else {
    hypotheses.push(
      `No matching operational incident found in the log for this date and location. ` +
      `Further investigation required to determine cause.`
    );
    actions.push('Cross-check with field staff shift reports and maintenance logs.');
    actions.push('Investigate potential data quality issues (AFC downtime, reporting delays).');
    if (exc.delta_pct > 0) {
      actions.push('Check for unlogged events (concerts, festivals, exams) in the service area.');
    } else {
      actions.push('Review CCTV or AFC entry logs to confirm actual passenger counts.');
    }
  }

  return {
    exception:  exc,
    facts,
    relatedIncs: related,
    hypotheses,
    actions,
    hasEvidence: related.length > 0,
  };
}

/**
 * Classify anomaly type for display labels.
 * Returns 'DROP' | 'SPIKE' | 'NORMAL'
 */
export function anomalyType(deltaPct) {
  if (deltaPct <= -THRESHOLD_PCT) return 'DROP';
  if (deltaPct >=  THRESHOLD_PCT) return 'SPIKE';
  return 'NORMAL';
}
