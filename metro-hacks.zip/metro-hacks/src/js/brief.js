/**
 * TransitPulse — brief.js
 * Morning Brief generator.
 *
 * Produces a deterministic, structured plain-text report from computed
 * data. No AI, no network calls, no randomness.
 *
 * Output format: human-readable plain text suitable for download as .txt
 * and display in a monospace <pre> block.
 */

'use strict';

import { totalRidership, prevDate, getDateList }  from './data.js';
import { detectExceptions, buildEvidence, THRESHOLD_PCT } from './anomaly.js';

// ── Formatting helpers ───────────────────────────────────────────────────────

function fmt(n) {
  if (n == null || isNaN(n)) return '—';
  return n.toLocaleString('en-IN');
}

function pctStr(current, previous) {
  if (!previous || previous === 0) return 'N/A';
  const v = ((current - previous) / previous) * 100;
  return (v >= 0 ? '+' : '') + v.toFixed(1) + '%';
}

function pad(s, width) {
  return String(s).padStart(width, ' ');
}

const LINE  = '─'.repeat(64);
const DLINE = '═'.repeat(64);

// ── Main generator ───────────────────────────────────────────────────────────

/**
 * Generate the Morning Brief text.
 *
 * @param {Array}  ridership  - full ridership dataset
 * @param {Array}  incidents  - full incidents dataset
 * @param {string} date       - YYYY-MM-DD — the report date
 * @param {string} opFilter   - 'ALL' | 'METRO' | 'BRTS' | 'AMTS'
 * @returns {string} formatted plain-text brief
 */
export function generateBrief(ridership, incidents, date, opFilter = 'ALL') {
  const prev       = prevDate(ridership, date);
  const total      = totalRidership(ridership, date, opFilter);
  const prevTotal  = prev ? totalRidership(ridership, prev, opFilter) : null;

  const metroTotal = totalRidership(ridership, date, 'METRO');
  const brtsTotal  = totalRidership(ridership, date, 'BRTS');
  const amtsTotal  = totalRidership(ridership, date, 'AMTS');
  const prevMetro  = prev ? totalRidership(ridership, prev, 'METRO') : null;
  const prevBRTS   = prev ? totalRidership(ridership, prev, 'BRTS')  : null;
  const prevAMTS   = prev ? totalRidership(ridership, prev, 'AMTS')  : null;

  const exceptions = detectExceptions(ridership, date, opFilter);
  const highExcs   = exceptions.filter(e => e.severity === 'HIGH');
  const top3       = exceptions.slice(0, 3);

  const dayIncs    = incidents.filter(
    i => i.date === date && (opFilter === 'ALL' || i.operator === opFilter)
  );
  const highIncs   = dayIncs.filter(i => i.severity === 'high');

  const dateList   = getDateList(ridership);
  const totalDays  = dateList.length;
  const dateIdx    = dateList.indexOf(date);

  const generatedAt = new Date().toLocaleString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', timeZoneName: 'short',
  });

  let b = '';

  // ── Header ──────────────────────────────────────────────────────────────
  b += DLINE + '\n';
  b += '  TRANSITPULSE — OPERATIONS MORNING BRIEF\n';
  b += `  Report Date   : ${date}\n`;
  b += `  Operator Scope: ${opFilter === 'ALL' ? 'All Operators (Metro + BRTS + AMTS)' : opFilter}\n`;
  b += `  Generated     : ${generatedAt}\n`;
  b += `  Data Range    : ${dateList[0]} → ${dateList[totalDays - 1]}  (${totalDays} days)\n`;
  b += DLINE + '\n\n';

  b += `  ⚠  SYNTHETIC DEMO DATA — Not actual Ahmedabad transit statistics.\n`;
  b += `     All figures are illustrative only. Built for Gujarat Metro Hacks PS-13.\n\n`;

  // ── 1. Executive Summary ─────────────────────────────────────────────────
  b += LINE + '\n';
  b += `  SECTION 1 — EXECUTIVE SUMMARY\n`;
  b += LINE + '\n';
  b += `  Total Ridership (${date})  : ${pad(fmt(total), 10)} passengers\n`;
  b += `  Previous Day   (${prev || 'N/A'})  : ${pad(fmt(prevTotal ?? 0), 10)} passengers\n`;
  b += `  Day-on-Day Change            : ${pctStr(total, prevTotal)}`;
  if (prevTotal) {
    const diff = total - prevTotal;
    b += `  (${diff >= 0 ? '+' : ''}${fmt(diff)} pax)`;
  }
  b += '\n\n';
  b += `  Operator Breakdown:\n`;
  b += `  ${'METRO'.padEnd(6)}: ${pad(fmt(metroTotal), 9)} pax   ${pctStr(metroTotal, prevMetro)} vs prev\n`;
  b += `  ${'BRTS'.padEnd(6)} : ${pad(fmt(brtsTotal),  9)} pax   ${pctStr(brtsTotal,  prevBRTS)}  vs prev\n`;
  b += `  ${'AMTS'.padEnd(6)} : ${pad(fmt(amtsTotal),  9)} pax   ${pctStr(amtsTotal,  prevAMTS)}  vs prev\n\n`;
  b += `  Exceptions Detected : ${exceptions.length}  (${highExcs.length} HIGH, ${exceptions.length - highExcs.length} MEDIUM)\n`;
  b += `  Incidents Recorded  : ${dayIncs.length}  (${highIncs.length} HIGH)\n\n`;

  // ── 2. Anomaly Log ───────────────────────────────────────────────────────
  b += LINE + '\n';
  b += `  SECTION 2 — ANOMALY / EXCEPTION LOG  (threshold: ±${THRESHOLD_PCT}%)\n`;
  b += LINE + '\n';

  if (exceptions.length === 0) {
    b += `  No anomalies detected exceeding the ±${THRESHOLD_PCT}% deviation threshold.\n\n`;
  } else {
    exceptions.forEach((exc, i) => {
      const sign   = exc.delta_pct >= 0 ? '+' : '';
      const ev     = buildEvidence(exc, incidents);

      b += `  [${String(i + 1).padStart(2, '0')}] ${exc.severity.padEnd(6)} — ${exc.operator} · ${exc.route_station}\n`;
      b += `        Observed Ridership : ${fmt(exc.ridership)}\n`;
      b += `        Baseline (7-day avg): ${fmt(exc.baseline)}\n`;
      b += `        Deviation          : ${sign}${exc.delta_pct.toFixed(1)}%\n`;

      if (ev.hasEvidence) {
        ev.relatedIncs.forEach(inc => {
          b += `        [INCIDENT] ${inc.title} — ${inc.location}\n`;
          b += `                   ${inc.description}\n`;
        });
        b += `        [NOTE] Incident on same date/location. Correlation noted; causation unconfirmed.\n`;
      } else {
        b += `        [NOTE] No matching incident found. Further investigation required.\n`;
      }
      b += '\n';
    });
  }

  // ── 3. Operational Incidents ─────────────────────────────────────────────
  b += LINE + '\n';
  b += `  SECTION 3 — OPERATIONAL INCIDENTS (${date})\n`;
  b += LINE + '\n';

  if (dayIncs.length === 0) {
    b += `  No incidents recorded for ${date}.\n\n`;
  } else {
    dayIncs.forEach((inc, i) => {
      b += `  [${String(i + 1).padStart(2, '0')}] ${inc.severity.toUpperCase().padEnd(7)} — ${inc.operator} · ${inc.location}\n`;
      b += `        ${inc.title}\n`;
      b += `        ${inc.description}\n\n`;
    });
  }

  // ── 4. Top 3 Priority Exceptions ─────────────────────────────────────────
  b += LINE + '\n';
  b += `  SECTION 4 — TOP ${top3.length} PRIORITY EXCEPTIONS (detailed)\n`;
  b += LINE + '\n';

  if (top3.length === 0) {
    b += `  No priority exceptions today.\n\n`;
  } else {
    top3.forEach((exc, i) => {
      const ev   = buildEvidence(exc, incidents);
      const sign = exc.delta_pct >= 0 ? '+' : '';

      b += `  Priority ${i + 1}: ${exc.operator} — ${exc.route_station}\n`;
      b += `  ${'─'.repeat(60)}\n`;

      b += `  OBSERVED FACTS:\n`;
      ev.facts.forEach(f => { b += `    • ${f}\n`; });

      b += `\n  RELATED INCIDENTS:\n`;
      if (ev.relatedIncs.length > 0) {
        ev.relatedIncs.forEach(inc => {
          b += `    • [${inc.severity.toUpperCase()}] ${inc.title}\n`;
          b += `      Location   : ${inc.location}\n`;
          b += `      Description: ${inc.description}\n`;
        });
      } else {
        b += `    • None found in the incident log for this date and location.\n`;
      }

      b += `\n  POSSIBLE EXPLANATIONS:\n`;
      ev.hypotheses.forEach(h => { b += `    • ${h}\n`; });

      b += `\n  RECOMMENDED ACTIONS:\n`;
      ev.actions.forEach(a => { b += `    → ${a}\n`; });

      b += '\n';
    });
  }

  // ── 5. Recommended Follow-Up Actions ─────────────────────────────────────
  b += LINE + '\n';
  b += `  SECTION 5 — RECOMMENDED FOLLOW-UP ACTIONS\n`;
  b += LINE + '\n';

  const actions = [];
  if (highExcs.length > 0) {
    actions.push(`URGENT: Review ${highExcs.length} HIGH-severity exception(s) with field supervisors within 2 hours.`);
  }
  highIncs.forEach(inc => {
    actions.push(`Confirm resolution status of: "${inc.title}" at ${inc.location}.`);
  });
  const unexplained = exceptions.filter(e => !buildEvidence(e, incidents).hasEvidence);
  if (unexplained.length > 0) {
    actions.push(`${unexplained.length} anomaly(ies) have no matching incident. Schedule investigation.`);
  }
  if (prevTotal && total < prevTotal * 0.9) {
    actions.push(`Network-wide ridership is down ${(((prevTotal - total) / prevTotal) * 100).toFixed(1)}%. Consider service-wide review.`);
  }
  actions.push('Update incident log with any new information from overnight maintenance reports.');
  actions.push('Circulate this brief to Metro, BRTS, and AMTS duty managers by 07:30 IST.');
  actions.push('Archive this report in the daily operations log folder.');

  actions.forEach((a, i) => {
    b += `  ${i + 1}. ${a}\n`;
  });
  b += '\n';

  // ── 6. Data Limitations ──────────────────────────────────────────────────
  b += LINE + '\n';
  b += `  SECTION 6 — DATA LIMITATIONS & METHODOLOGY NOTES\n`;
  b += LINE + '\n';
  b += `  • This report uses SYNTHETIC DEMO DATA generated for Gujarat Metro Hacks PS-13.\n`;
  b += `  • Anomaly detection: ±${THRESHOLD_PCT}% threshold against 7-day rolling average (min 3 data points).\n`;
  b += `  • Severity thresholds: HIGH = |Δ| ≥ 35%, MEDIUM = |Δ| ≥ ${THRESHOLD_PCT}%.\n`;
  b += `  • Incident matching: keyword-based overlap between station name and incident location.\n`;
  b += `  • Correlation between incidents and ridership changes is NOT proven causation.\n`;
  b += `  • Production system should use: live GTFS/AFC feeds, ML-based anomaly detection,\n`;
  b += `    structured incident database with operator/station foreign keys.\n\n`;

  // ── Footer ───────────────────────────────────────────────────────────────
  b += DLINE + '\n';
  b += `  End of Morning Brief — TransitPulse v1.0\n`;
  b += `  Gujarat Metro Hacks 2024 · PS-13: The Two-Minute Morning Brief\n`;
  b += `  Generated ${generatedAt}\n`;
  b += DLINE + '\n';

  return b;
}

// ── Export as CSV utility ────────────────────────────────────────────────────

/**
 * Serialise ridership rows to CSV string.
 * @param {Array} rows
 * @returns {string} CSV text with header
 */
export function exportToCSV(rows) {
  let csv = 'date,operator,route_station,ridership\n';
  rows.forEach(r => {
    const station = r.route_station.includes(',')
      ? `"${r.route_station.replace(/"/g, '""')}"`
      : r.route_station;
    csv += `${r.date},${r.operator},${station},${r.ridership}\n`;
  });
  return csv;
}

/**
 * Trigger a file download in the browser.
 * @param {string} content   - file content
 * @param {string} filename  - suggested filename
 * @param {string} mime      - MIME type
 */
export function downloadFile(content, filename, mime = 'text/plain;charset=utf-8') {
  const blob = new Blob([content], { type: mime });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
