/**
 * TransitPulse — ui.js
 * All DOM rendering helpers (KPI cards, tables, incidents, exceptions).
 * Pure functions — no side effects beyond writing to passed-in DOM nodes.
 */

'use strict';

import { totalRidership, prevDate, rollingBaseline } from './data.js';
import { detectExceptions, buildEvidence, anomalyType } from './anomaly.js';

// ── Safe HTML escape ─────────────────────────────────────────────────────────
export function esc(s) {
  const d = document.createElement('span');
  d.appendChild(document.createTextNode(String(s)));
  return d.innerHTML;
}

// ── Number formatting ────────────────────────────────────────────────────────
export function fmt(n) {
  if (n == null || isNaN(n)) return '—';
  return n.toLocaleString('en-IN');
}

function pctStr(a, b) {
  if (!b || b === 0) return null;
  return ((a - b) / b) * 100;
}

function signStr(n) {
  return n >= 0 ? '+' : '';
}

// ── KPI Cards ────────────────────────────────────────────────────────────────

/**
 * Update all seven KPI cards for the current date/filter.
 *
 * @param {object} els       - map of card element IDs to DOM elements
 * @param {Array}  ridership - full ridership dataset
 * @param {Array}  incidents - full incidents dataset
 * @param {string} date      - YYYY-MM-DD
 * @param {string} op        - 'ALL' | operator
 */
export function renderKPIs(ridership, incidents, date, op) {
  const total     = totalRidership(ridership, date, op);
  const prev      = prevDate(ridership, date);
  const prevTotal = prev ? totalRidership(ridership, prev, op) : null;
  const delta     = pctStr(total, prevTotal);

  // Total ridership
  _kpiSet('kpi-total', fmt(total),
    delta !== null
      ? `<span class="${delta >= 0 ? 'trend-up' : 'trend-down'}">${signStr(delta)}${delta.toFixed(1)}% vs ${prev}</span>`
      : '<span class="trend-flat">No prior day</span>'
  );

  // Δ card
  if (delta !== null) {
    const diff = total - (prevTotal || 0);
    _kpiSet('kpi-delta',
      `<span style="color:${delta >= 0 ? '#34d399' : '#f87171'}">${signStr(delta)}${delta.toFixed(1)}%</span>`,
      `<span class="${delta >= 0 ? 'trend-up' : 'trend-down'}">${signStr(diff)}${fmt(diff)} passengers</span>`
    );
  } else {
    _kpiSet('kpi-delta', 'N/A', '<span class="trend-flat">Insufficient history</span>');
  }

  // Per-operator
  ['METRO', 'BRTS', 'AMTS'].forEach(eachOp => {
    const v   = totalRidership(ridership, date, eachOp);
    const pv  = prev ? totalRidership(ridership, prev, eachOp) : null;
    const d   = pctStr(v, pv);
    const id  = 'kpi-' + eachOp.toLowerCase();
    _kpiSet(id, fmt(v),
      d !== null
        ? `<span class="${d >= 0 ? 'trend-up' : 'trend-down'}">${signStr(d)}${d.toFixed(1)}% vs prev</span>`
        : '<span class="trend-flat">—</span>'
    );
  });

  // Exceptions
  const excs    = detectExceptions(ridership, date, op);
  const highExc = excs.filter(e => e.severity === 'HIGH').length;
  _kpiSet('kpi-exc', excs.length,
    `<span style="color:${highExc > 0 ? '#f87171' : '#64748b'}">${highExc} HIGH severity</span>`
  );

  // Incidents
  const incs    = incidents.filter(i => i.date === date && (op === 'ALL' || i.operator === op));
  const highInc = incs.filter(i => i.severity === 'high').length;
  _kpiSet('kpi-inc', incs.length,
    `<span style="color:${highInc > 0 ? '#f87171' : '#64748b'}">${highInc} HIGH severity</span>`
  );
}

function _kpiSet(id, value, subHtml) {
  const valEl = document.getElementById(id);
  const subEl = document.getElementById(id + '-sub');
  if (valEl) valEl.innerHTML = String(value);
  if (subEl) subEl.innerHTML = subHtml || '';
}

// ── Exceptions Table ─────────────────────────────────────────────────────────

/**
 * Render the exceptions table.
 *
 * @param {HTMLElement} tbodyEl - <tbody> element
 * @param {HTMLElement} emptyEl - empty-state element
 * @param {HTMLElement} wrapEl  - table wrapper
 * @param {Array}       excs    - exception objects from detectExceptions()
 * @param {Array}       incidents
 */
export function renderExceptionsTable(tbodyEl, emptyEl, wrapEl, excs, incidents) {
  if (excs.length === 0) {
    if (wrapEl)  wrapEl.style.display  = 'none';
    if (emptyEl) emptyEl.style.display = 'block';
    return;
  }
  if (wrapEl)  wrapEl.style.display  = '';
  if (emptyEl) emptyEl.style.display = 'none';

  tbodyEl.innerHTML = excs.map(exc => {
    const ev       = buildEvidence(exc, incidents);
    const sign     = exc.delta_pct >= 0 ? '+' : '';
    const type     = anomalyType(exc.delta_pct);
    const typeBadge = type === 'DROP'
      ? '<span class="badge badge-red">▼ DROP</span>'
      : '<span class="badge badge-amber">▲ SPIKE</span>';
    const sevBadge = exc.severity === 'HIGH'
      ? '<span class="badge badge-red">HIGH</span>'
      : '<span class="badge badge-amber">MEDIUM</span>';
    const opBadge  = {
      METRO: 'badge-purple', BRTS: 'badge-green', AMTS: 'badge-amber',
    }[exc.operator] || 'badge-gray';
    const noteHtml = ev.hasEvidence
      ? `<span style="color:#fcd34d">⚑ ${esc(ev.relatedIncs[0].title)}</span>`
      : `<span style="color:#64748b">No incident — investigate</span>`;

    return `<tr>
      <td><span class="badge ${esc(opBadge)}">${esc(exc.operator)}</span></td>
      <td style="max-width:150px;word-break:break-word">${esc(exc.route_station)}</td>
      <td class="td-mono">${esc(fmt(exc.ridership))}</td>
      <td class="td-mono">${esc(fmt(exc.baseline))}</td>
      <td class="td-mono" style="color:${exc.delta_pct >= 0 ? '#34d399' : '#f87171'};font-weight:700">
        ${esc(sign + exc.delta_pct.toFixed(1) + '%')}
      </td>
      <td>${typeBadge}</td>
      <td>${sevBadge}</td>
      <td>${noteHtml}</td>
    </tr>`;
  }).join('');
}

// ── Incidents Panel ───────────────────────────────────────────────────────────

/**
 * Render the incidents list panel.
 *
 * @param {HTMLElement} listEl  - container for incident cards
 * @param {HTMLElement} emptyEl - empty-state element
 * @param {Array}       incs    - filtered incidents for this date/op
 */
export function renderIncidents(listEl, emptyEl, incs) {
  if (incs.length === 0) {
    if (listEl)  listEl.style.display  = 'none';
    if (emptyEl) emptyEl.style.display = 'block';
    return;
  }
  if (listEl)  listEl.style.display  = '';
  if (emptyEl) emptyEl.style.display = 'none';

  const BADGE_MAP = { high: 'badge-red', medium: 'badge-amber', low: 'badge-blue' };
  const SEV_LABEL = { high: 'HIGH', medium: 'MED', low: 'LOW' };

  listEl.innerHTML = incs.map(inc => {
    const badgeCls  = BADGE_MAP[inc.severity]  || 'badge-gray';
    const sevLabel  = SEV_LABEL[inc.severity]  || inc.severity.toUpperCase();

    return `<div class="incident-card sev-${esc(inc.severity)}">
      <div class="incident-header">
        <span class="incident-title">${esc(inc.title)}</span>
        <span class="badge ${esc(badgeCls)}">${esc(sevLabel)}</span>
      </div>
      <div class="incident-meta">${esc(inc.operator)} · ${esc(inc.location)} · ${esc(inc.date)}</div>
      <div class="incident-body">${esc(inc.description)}</div>
    </div>`;
  }).join('');
}

// ── Evidence Deep-Dive ────────────────────────────────────────────────────────

/**
 * Render a structured evidence block for one exception.
 * @param {HTMLElement} containerEl - target container
 * @param {object}      evidence    - output of buildEvidence()
 */
export function renderEvidenceBlock(containerEl, evidence) {
  if (!containerEl) return;
  const { facts, relatedIncs, hypotheses, actions } = evidence;

  const rows = [
    ...facts.map(f       => ({ tag: 'FACT',        cls: 'et-fact',   text: f })),
    ...relatedIncs.map(i => ({ tag: 'INCIDENT',    cls: 'et-inc',    text: `${i.title}: ${i.description}` })),
    ...hypotheses.map(h  => ({ tag: 'HYPOTHESIS',  cls: 'et-hypo',   text: h })),
    ...actions.map(a     => ({ tag: 'ACTION',       cls: 'et-action', text: a })),
  ];

  containerEl.innerHTML = `<div class="evidence-block">${
    rows.map(r => `<div class="evidence-row">
      <span class="evidence-tag ${esc(r.cls)}">${esc(r.tag)}</span>
      <span class="evidence-text">${esc(r.text)}</span>
    </div>`).join('')
  }</div>`;
}

// ── Utility: show/hide element ────────────────────────────────────────────────
export function show(el) { if (el) el.style.display = ''; }
export function hide(el) { if (el) el.style.display = 'none'; }
export function toggle(el, condition) { condition ? show(el) : hide(el); }
