/**
 * TransitPulse — data.js
 * Synthetic sample-data generator and data-access layer.
 *
 * All ridership figures are SYNTHETIC. They do NOT represent actual
 * Ahmedabad Metro, BRTS, or AMTS statistics.
 *
 * Responsibilities:
 *  - Generate 14-day synthetic ridership dataset (Metro / BRTS / AMTS)
 *  - Generate operational incidents dataset
 *  - Provide low-level data-access helpers
 *  - Parse imported CSV ridership files
 */

'use strict';

// ── Constants ───────────────────────────────────────────────────────────────

export const OPERATORS = ['METRO', 'BRTS', 'AMTS'];

export const METRO_STATIONS = [
  'Vastral Gam',       'Nirant Cross Roads', 'Rabari Colony',   'Apparel Park',
  'Amraiwadi',         'Hatkeshwar',         'Rakhial',         'Naroda Road',
  'Bapu Dham',         'Kankaria East',      'Old High Court',  'Shahpur',
  'Gheekanta',         'Paldi',              'Ankur',           'Jivraj Park',
  'Vasna',             'Thaltej Gam',        'Jagatpur Road',   'Science City',
];

export const BRTS_ROUTES = [
  'R-01 Naroda–APMC',        'R-02 Lambha–Isanpur',
  'R-03 Chandkheda–Paldi',   'R-04 Ranip–Maninagar',
  'R-05 Bopal–Narol',        'R-06 Ghatlodiya–Vatva',
  'R-07 Sarkhej–Gandhinagar Hwy', 'R-08 Gota–SP Ring Rd',
];

export const AMTS_ROUTES = [
  'A-11 Kalupur–Bopal',       'A-12 Dariapur–Bapunagar',
  'A-15 Rakhial–Vastral',     'A-19 Naroda–CTM',
  'A-22 Chandkheda–Gota',     'A-31 Vatva–Maninagar',
  'A-45 Science City–Sola',   'A-52 Navrangpura–Bodakdev',
];

// Synthetic base ridership (passengers/day at median conditions)
const BASE_METRO = {
  'Vastral Gam': 3200, 'Nirant Cross Roads': 3480, 'Rabari Colony': 3760,
  'Apparel Park': 4040, 'Amraiwadi': 4320, 'Hatkeshwar': 4600,
  'Rakhial': 4880, 'Naroda Road': 5160, 'Bapu Dham': 5440,
  'Kankaria East': 5720, 'Old High Court': 6000, 'Shahpur': 6280,
  'Gheekanta': 6560, 'Paldi': 6840, 'Ankur': 5960, 'Jivraj Park': 5080,
  'Vasna': 4200, 'Thaltej Gam': 5720, 'Jagatpur Road': 4840, 'Science City': 5500,
};
const BASE_BRTS = {
  'R-01 Naroda–APMC': 5500, 'R-02 Lambha–Isanpur': 5920,
  'R-03 Chandkheda–Paldi': 6340, 'R-04 Ranip–Maninagar': 6760,
  'R-05 Bopal–Narol': 7180, 'R-06 Ghatlodiya–Vatva': 7600,
  'R-07 Sarkhej–Gandhinagar Hwy': 8020, 'R-08 Gota–SP Ring Rd': 8440,
};
const BASE_AMTS = {
  'A-11 Kalupur–Bopal': 4100, 'A-12 Dariapur–Bapunagar': 4410,
  'A-15 Rakhial–Vastral': 4720, 'A-19 Naroda–CTM': 5030,
  'A-22 Chandkheda–Gota': 5340, 'A-31 Vatva–Maninagar': 5650,
  'A-45 Science City–Sola': 5960, 'A-52 Navrangpura–Bodakdev': 6270,
};

// ── Date utilities ──────────────────────────────────────────────────────────

/** Returns today's date string YYYY-MM-DD (local timezone). */
export function todayStr() {
  const d = new Date();
  return _toDateStr(d);
}

/** Add n days to a YYYY-MM-DD string, return new YYYY-MM-DD string. */
export function addDays(ds, n) {
  const d = new Date(ds + 'T00:00:00');
  d.setDate(d.getDate() + n);
  return _toDateStr(d);
}

function _toDateStr(d) {
  return d.toISOString().slice(0, 10);
}

// Dataset starts 14 days before today so it always ends "yesterday"
export const BASE_DATE = addDays(todayStr(), -14);

/** Build a date string for offset days from BASE_DATE. */
export function buildDate(offset) {
  return addDays(BASE_DATE, offset);
}

// ── Seeded pseudo-random ────────────────────────────────────────────────────

/** Lehmer LCG — deterministic, not cryptographic. Returns [0,1). */
function seededRng(seed) {
  let s = Math.abs(seed) % 2147483647 || 1;
  return () => { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
}

// ── Sample data generation ──────────────────────────────────────────────────

/**
 * Generate 14 days of synthetic ridership data.
 * Returns array of { date, operator, route_station, ridership }.
 *
 * Planted anomalies:
 *   Day 9  — Metro, Vastral Gam         : ~48% drop  (ticket gate failure)
 *   Day 11 — BRTS, R-03 Chandkheda–Paldi: ~62% spike (Science City Expo)
 */
export function generateSampleRidership() {
  const rows = [];

  for (let day = 0; day < 14; day++) {
    const dateS  = buildDate(day);
    const dow    = new Date(dateS + 'T00:00:00').getDay(); // 0=Sun,6=Sat
    const isWeekend = (dow === 0 || dow === 6);
    const wkMult = isWeekend ? 0.70 : 1.0;
    const rng    = seededRng(day * 9999 + 42);

    // Metro
    METRO_STATIONS.forEach(st => {
      let anomaly = 1.0;
      if (st === 'Vastral Gam' && day === 9) anomaly = 0.48;  // planted drop
      const base  = BASE_METRO[st];
      const noise = 0.88 + rng() * 0.26;
      rows.push({
        date: dateS, operator: 'METRO', route_station: st,
        ridership: Math.max(0, Math.round(base * wkMult * noise * anomaly)),
      });
    });

    // BRTS
    BRTS_ROUTES.forEach(rt => {
      let anomaly = 1.0;
      if (rt === 'R-03 Chandkheda–Paldi' && day === 11) anomaly = 1.62; // planted spike
      const base  = BASE_BRTS[rt];
      const noise = 0.88 + rng() * 0.26;
      rows.push({
        date: dateS, operator: 'BRTS', route_station: rt,
        ridership: Math.max(0, Math.round(base * wkMult * noise * anomaly)),
      });
    });

    // AMTS
    AMTS_ROUTES.forEach(rt => {
      const base  = BASE_AMTS[rt];
      const noise = 0.88 + rng() * 0.26;
      rows.push({
        date: dateS, operator: 'AMTS', route_station: rt,
        ridership: Math.max(0, Math.round(base * wkMult * noise)),
      });
    });
  }

  return rows;
}

/**
 * Generate synthetic operational incidents.
 * Returns array of { date, operator, location, severity, title, description }.
 */
export function generateSampleIncidents() {
  return [
    {
      date: buildDate(1), operator: 'METRO', location: 'Shahpur',
      severity: 'medium', title: 'Ticket Gate Offline',
      description: '2 of 4 entry gates at Shahpur station reported out of service 08:15–10:40. Backup manual check-in deployed. Estimated 340 passengers affected.',
    },
    {
      date: buildDate(3), operator: 'BRTS', location: 'R-01 Naroda–APMC',
      severity: 'low', title: 'Bus Breakdown — Service Delay',
      description: 'Vehicle BT-0312 broke down near Naroda depot causing 22-minute delay on Route R-01. Replacement dispatched at 09:07. Service normalised by 09:35.',
    },
    {
      date: buildDate(5), operator: 'AMTS', location: 'A-19 Naroda–CTM',
      severity: 'low', title: 'Route Diversion — Road Repair',
      description: 'A-19 diverted via auxiliary road due to AUDA road repair near CTM crossing. Estimated delay 15 min/trip. Diversion active 06:00–18:00.',
    },
    {
      date: buildDate(7), operator: 'METRO', location: 'Kankaria East',
      severity: 'medium', title: 'Platform Screen Door Fault',
      description: 'Platform screen door on Track 2 at Kankaria East malfunctioned at 07:00. Single-track operation 07:00–09:30. Recovery protocol activated. ~1,200 pax impacted.',
    },
    {
      date: buildDate(9), operator: 'METRO', location: 'Vastral Gam',
      severity: 'high', title: 'Ticket Gate Malfunction — All 6 Gates',
      description: 'All 6 automated ticket gates at Vastral Gam failed 06:45–15:20 due to power supply unit failure in the AFC control cabinet. Manual fare collection deployed with severely reduced throughput (~40% of normal). Engineers on site from 08:30. Permanent fix completed 15:20.',
    },
    {
      date: buildDate(9), operator: 'METRO', location: 'Nirant Cross Roads',
      severity: 'low', title: 'Overflow Congestion from Vastral Gam',
      description: 'Passengers diverted from Vastral Gam incident created temporary platform congestion at Nirant Cross Roads. Additional RPF staff deployed. Resolved by 09:00.',
    },
    {
      date: buildDate(11), operator: 'BRTS', location: 'R-03 Chandkheda–Paldi',
      severity: 'low', title: 'Planned Event — Science City Regional Expo',
      description: 'Gujarat Regional Science Expo at Science City generated abnormally high demand on R-03 corridor. 6 additional buses deployed from 09:00–20:00. Ridership ~62% above baseline; operations handled without service disruption.',
    },
    {
      date: buildDate(12), operator: 'AMTS', location: 'A-52 Navrangpura–Bodakdev',
      severity: 'medium', title: 'Driver Shortage — Reduced Frequency',
      description: '3 drivers on A-52 called in sick. Service frequency reduced from every 12 min to every 22 min during peak hours (07:00–11:00, 17:00–21:00). Passengers advised via SMS alert.',
    },
    {
      date: buildDate(13), operator: 'METRO', location: 'Paldi',
      severity: 'low', title: 'Minor Signalling Irregularity',
      description: 'Brief OCS signalling irregularity at Paldi junction at 07:12. Resolved in 8 minutes by remote reset. No service interruption. Logged for preventive maintenance review.',
    },
  ];
}

// ── Aggregation helpers ─────────────────────────────────────────────────────

/**
 * Sum ridership for a given date + operator filter.
 * @param {Array}  rows   - full ridership array
 * @param {string} date   - YYYY-MM-DD
 * @param {string} op     - 'ALL' | 'METRO' | 'BRTS' | 'AMTS'
 */
export function totalRidership(rows, date, op = 'ALL') {
  return rows
    .filter(r => r.date === date && (op === 'ALL' || r.operator === op))
    .reduce((s, r) => s + r.ridership, 0);
}

/**
 * Return the sorted list of unique dates in the dataset.
 */
export function getDateList(rows) {
  return [...new Set(rows.map(r => r.date))].sort();
}

/**
 * Get the date immediately preceding `date` within the dataset.
 * Returns null if no prior date exists.
 */
export function prevDate(rows, date) {
  const dates = getDateList(rows);
  const idx   = dates.indexOf(date);
  return idx > 0 ? dates[idx - 1] : null;
}

/**
 * Compute a 7-day rolling average baseline for one operator+station.
 * Requires at least 3 prior days; returns null otherwise.
 */
export function rollingBaseline(rows, date, operator, station, window = 7) {
  const dates = getDateList(rows);
  const idx   = dates.indexOf(date);
  if (idx < 0) return null;

  const windowDates = dates.slice(Math.max(0, idx - window), idx);
  const vals = windowDates
    .map(d => {
      const r = rows.find(x => x.date === d && x.operator === operator && x.route_station === station);
      return r ? r.ridership : null;
    })
    .filter(v => v !== null);

  if (vals.length < 3) return null;
  return vals.reduce((s, v) => s + v, 0) / vals.length;
}

// ── CSV parsing ─────────────────────────────────────────────────────────────

/**
 * Parse a CSV string into ridership rows.
 * Expected columns (order-insensitive, header required):
 *   date, operator, route_station, ridership
 *
 * Returns { rows: Array, imported: Number, skipped: Number, errors: Array<string> }
 */
export function parseRidershipCSV(csvText) {
  const lines  = csvText.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  const result = { rows: [], imported: 0, skipped: 0, errors: [] };

  if (lines.length < 2) {
    result.errors.push('File appears empty or has no data rows.');
    return result;
  }

  // Parse header
  const header = parseCsvLine(lines[0]).map(h => h.toLowerCase().trim());
  const iDate   = header.indexOf('date');
  const iOp     = header.indexOf('operator');
  const iSt     = header.indexOf('route_station');
  const iRid    = header.indexOf('ridership');

  if ([iDate, iOp, iSt, iRid].includes(-1)) {
    result.errors.push('Missing required columns. Expected: date, operator, route_station, ridership');
    return result;
  }

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const parts = parseCsvLine(line);
    if (parts.length <= Math.max(iDate, iOp, iSt, iRid)) {
      result.skipped++;
      continue;
    }

    const date     = parts[iDate].trim();
    const op       = parts[iOp].trim().toUpperCase();
    const station  = parts[iSt].trim();
    const ridStr   = parts[iRid].trim();
    const rid      = parseInt(ridStr, 10);

    if (!/^\d{4}-\d{2}-\d{2}$/.test(date))              { result.skipped++; continue; }
    if (!OPERATORS.includes(op))                          { result.skipped++; continue; }
    if (!station)                                         { result.skipped++; continue; }
    if (isNaN(rid) || rid < 0)                            { result.skipped++; continue; }

    result.rows.push({ date, operator: op, route_station: station, ridership: rid });
    result.imported++;
  }

  return result;
}

/** Minimal RFC-4180 CSV line parser (handles double-quoted fields). */
function parseCsvLine(line) {
  const fields = [];
  let field = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuotes) {
      if (ch === '"' && line[i + 1] === '"') { field += '"'; i++; }
      else if (ch === '"')                   { inQuotes = false; }
      else                                   { field += ch; }
    } else {
      if (ch === '"')  { inQuotes = true; }
      else if (ch === ',') { fields.push(field); field = ''; }
      else             { field += ch; }
    }
  }
  fields.push(field);
  return fields;
}
